//
//  FileSharingCell.m
//  FileManager
//
//  Created by ami on 11/22/16.
//  Copyright © 2016 com.zaptechsolutions. All rights reserved.
//

#import "FileSharingCell.h"

@implementation FileSharingCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    // Configure the view for the selected state
}

@end
