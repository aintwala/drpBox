//
//  ListFilesVC.m
//  FileManager
//
//  Created by ami on 11/23/16.
//  Copyright © 2016 com.zaptechsolutions. All rights reserved.
//

#import "ListFilesVC.h"
#import <DropboxSDK/DropboxSDK.h>
#import "FileListCell.h"
#import "appShareManager.h"

@interface ListFilesVC ()
{
    NSArray *arrFileList, *arrPaths;
    NSString *strDocumentsDirectory, *strDropBoxFilePath;
    NSString *strLoadData, *strTempBoolValue;
    UITapGestureRecognizer *tap;
    NSString *string;
}

@end

@implementation ListFilesVC

- (void)viewDidLoad {
    [super viewDidLoad];
    arrDownloadData = [[NSMutableArray alloc]init];
    strLoadData  = [[NSString alloc]init];
    self.bannerView.adUnitID = @"ca-app-pub-4018971263267828/6787743794";
    self.bannerView.rootViewController = self;
    [self.bannerView loadRequest:[GADRequest request]];
    self.tblViewFileList.dataSource = self;
    self.tblViewFileList.delegate = self;
    [self performSelector:@selector(fetchAllDropboxData) withObject:nil afterDelay:1.0];
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
}

-(void)viewWillAppear:(BOOL)animated {
    [self.navigationController setToolbarHidden:YES animated:animated];
    self.navigationItem.title = @"Files List";
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

#pragma mark - DropBox

- (DBRestClient *)restClient {
    if (restClient == nil) {
        appShareManager *objAppShare = [appShareManager sharedManager];
        restClient = [[DBRestClient alloc] initWithSession:[DBSession sharedSession] userId:objAppShare.strDropBoxUserID];
        restClient.delegate = self;
    }
    return restClient;
}

-(void)fetchAllDropboxData {
    if (!strLoadData) {
        strLoadData = @"";
    }
    [self.restClient loadMetadata:strLoadData];
}

-(void)downloadFileFromDropBox:(NSString *)filePath {
    NSString *strTempFile = [NSString stringWithFormat:@"/%@",filePath];
    strDropBoxFilePath = [NSString stringWithFormat:@"%@",[[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0] stringByAppendingPathComponent:[strTempFile lastPathComponent]]];
    [self.restClient loadFile:strTempFile intoPath:strDropBoxFilePath];
    NSLog(@"%@",strDropBoxFilePath);
}

#pragma mark - DBRestClientDelegate Methods for Load Data

- (void)restClient:(DBRestClient*)client loadedMetadata:(DBMetadata *)metadata {
    for (int i = 0; i < [metadata.contents count]; i++) {
        DBMetadata *data = [metadata.contents objectAtIndex:i];
        [arrDownloadData addObject:data];
    }
    [self.view removeGestureRecognizer:tap];
    [_tblViewFileList reloadData];
}

- (void)restClient:(DBRestClient *)client loadMetadataFailedWithError:(NSError *)error
{
    [_tblViewFileList reloadData];
}

#pragma mark - DBRestClientDelegate Methods for Download Data

- (void)restClient:(DBRestClient*)client loadedFile:(NSString*)destPath {
    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"" message:@"File download successfully." delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
    [alert show];
    [self fileManager];
}

-(void)restClient:(DBRestClient *)client loadFileFailedWithError:(NSError *)error {
}

#pragma mark - UITableView Delegate Methods

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [arrDownloadData count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *MyIdentifier = @"FileListCell";
    FileListCell *cell = [_tblViewFileList dequeueReusableCellWithIdentifier:MyIdentifier];
    if (cell == nil) {
        cell = [[FileListCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:MyIdentifier];
    }
    cell.backgroundColor = [UIColor clearColor];
    DBMetadata *metadata = [arrDownloadData objectAtIndex:indexPath.row];
    cell.lblFileName.text = metadata.filename;
    cell.imgViewFile.image = [UIImage imageNamed:[NSString stringWithFormat:@"%@48", metadata.icon]];
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    DBMetadata *metadata = [arrDownloadData objectAtIndex:indexPath.row];
    NSString *strTemp = metadata.filename;
    [self downloadFileFromDropBox:strTemp];
}

#pragma mark - File Download Method

-(void)fileDownloadFromDropBox:(NSIndexPath *)sender {
    UIButton *btnDownload = (UIButton *)sender;
    [self performSelector:@selector(downloadFileFromDropBox:) withObject:[btnDownload titleForState:UIControlStateDisabled] afterDelay:.1];
}

#pragma mark - Fetching file list method

-(void)fileManager {
    @try {
        arrPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
        strDocumentsDirectory = [arrPaths objectAtIndex:0];
        arrFileList = [[NSFileManager defaultManager] subpathsOfDirectoryAtPath:strDocumentsDirectory  error:nil];
        NSLog(@"files array %@", arrFileList);
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
}

@end
