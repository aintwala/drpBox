//
//  ListFilesVC.h
//  FileManager
//
//  Created by ami on 11/23/16.
//  Copyright © 2016 com.zaptechsolutions. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <DropboxSDK/DropboxSDK.h>
@import GoogleMobileAds;
@interface ListFilesVC : UIViewController <UITableViewDelegate, UITableViewDataSource, DBRestClientDelegate, UIDocumentInteractionControllerDelegate>
{
    NSMutableArray *arrDownloadData;
    DBRestClient *restClient;
}

@property (weak, nonatomic) IBOutlet GADBannerView *bannerView;
@property (weak, nonatomic) IBOutlet UITableView *tblViewFileList;
@property (nonatomic, retain) UIDocumentInteractionController *documentInteractionController;
-(void)fetchAllDropboxData;
@end
