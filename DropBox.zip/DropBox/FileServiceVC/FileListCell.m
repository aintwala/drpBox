//
//  FileListCell.m
//  FileManager
//
//  Created by ami on 11/23/16.
//  Copyright © 2016 com.zaptechsolutions. All rights reserved.
//

#import "FileListCell.h"

@implementation FileListCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
