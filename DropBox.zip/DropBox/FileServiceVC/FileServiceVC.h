//
//  FileServiceVC.h
//  FileManager
//
//  Created by nilomi on 11/14/16.
//  Copyright © 2016 com.zaptechsolutions. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <DropboxSDK/DropboxSDK.h>
#import "GTMOAuth2ViewControllerTouch.h"
#import "GTLDrive.h"
@import GoogleMobileAds;

@interface FileServiceVC : UIViewController <UITableViewDelegate, UITableViewDataSource, DBRestClientDelegate>
{
    NSMutableArray *arrDownloadData;
   // DBRestClient *restClient;
}
@property (weak, nonatomic) IBOutlet GADBannerView *bannerView;
@property (nonatomic, readonly) DBRestClient *restClient;
@property (weak, nonatomic) IBOutlet UIView *fileSharingPopUp;
- (IBAction)btnFileSharingDropBox:(id)sender;
- (IBAction)btnFileSharingGoogleDrive:(id)sender;
@property (weak, nonatomic) IBOutlet UITableView *tblViewFileSharing;
@property (weak, nonatomic) IBOutlet UIButton *btnGoogleDrive;
@property (weak, nonatomic) IBOutlet UIButton *btnDropbox;
@property BOOL isDropboxBtn;
@property (nonatomic, strong) GTLServiceDrive *service;
@property (nonatomic, strong) UITextView *output;

@end
