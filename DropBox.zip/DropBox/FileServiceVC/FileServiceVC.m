//
//  FileServiceVC.m
//  FileManager
//
//  Created by nilomi on 11/14/16.
//  Copyright © 2016 com.zaptechsolutions. All rights reserved.
//

#import "FileServiceVC.h"
#import <DropboxSDK/DropboxSDK.h>
#import "FileSharingCell.h"
#import "ListFilesVC.h"
#import "AppDelegate.h"
#import "appShareManager.h"

@import GoogleMobileAds;


static NSString *const kKeychainItemName = @"Drive API";
static NSString *const kClientID = @"457512105321-0jm2mt6iqtp1d6tm8hfp3u3ef146bivk.apps.googleusercontent.com";
static NSString *const kClientSecret = @"AIzaSyAI4sakod2DSEOjfjrQjR8dY5YRr5s7ozI";

@interface FileServiceVC ()
{
    NSArray *arrFileList, *arrPaths;
    NSString *strDocumentsDirectory, *strDropBoxFilePath;
    NSString *strLoadData, *strTempBoolValue;
    UITapGestureRecognizer *tap;
    AppDelegate *appDelegate;
    UITapGestureRecognizer *tapRecognizer;
    appShareManager *objAppShare;
    NSMutableArray *driveFiles;
    NSMutableArray *driveImage;
}

@end

@implementation FileServiceVC
@synthesize service = _service;
@synthesize output = _output;

- (void)viewDidLoad {
    [super viewDidLoad];
    tapRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dismissKeyboard)];
    [self.view addGestureRecognizer:tapRecognizer];
    objAppShare = [appShareManager sharedManager];
    self.bannerView.adUnitID = @"ca-app-pub-4018971263267828/6787743794";
    self.bannerView.rootViewController = self;
    [self.bannerView loadRequest:[GADRequest request]];
    self.fileSharingPopUp.hidden = YES;
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(dropboxLoginDone) name:@"OPEN_DROPBOX_VIEW" object:nil];
    UIBarButtonItem *addButton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(plusButtonPressed:)];
    self.navigationController.navigationBar.topItem.rightBarButtonItem = addButton;
    addButton.tintColor =[UIColor whiteColor];
    self.tblViewFileSharing.dataSource = self;
    self.tblViewFileSharing.delegate = self;
}

-(void)viewWillAppear:(BOOL)animated {
    [self.navigationController setToolbarHidden:YES animated:animated];
    self.navigationItem.title = @"File Services";
    self.navigationItem.backBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"" style:UIBarButtonItemStylePlain target:nil action:nil];
    [self.navigationController.navigationBar
     setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor whiteColor]}];
    [_tblViewFileSharing reloadData];
}

- (void)viewDidDisappear:(BOOL)animated {
    _fileSharingPopUp.hidden = YES;
}

-(void)dismissKeyboard {
    [self.view removeGestureRecognizer:tapRecognizer];
    [_fileSharingPopUp  resignFirstResponder];
    self.fileSharingPopUp.hidden = YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

#pragma mark - Popup View

- (void)plusButtonPressed:(id)sender {
    tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dismissPopup)];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, .25 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
        self.fileSharingPopUp.hidden = NO;
        [self showAnimate];
    });
    [self.view addGestureRecognizer:tap];
}

- (void)showAnimate {
    self.fileSharingPopUp.transform =CGAffineTransformMakeScale(.01, .01);
    [UIView animateWithDuration:.25 animations:^{
        self.fileSharingPopUp.transform = CGAffineTransformIdentity;
    }];
}

-(void)dismissPopup {
    [self.view removeGestureRecognizer:tap];
    [self.fileSharingPopUp resignFirstResponder];
    self.fileSharingPopUp.hidden = YES;
}

- (BOOL)slideNavigationControllerShouldDisplayLeftMenu {
    return YES;
}


#pragma mark - button Actions

- (IBAction)btnFileSharingGoogleDrive:(id)sender {
    if (!self.service.authorizer.canAuthorize) {
        // Not yet authorized, request authorization by pushing the login UI onto the UI stack.
        [self presentViewController:[self createAuthController] animated:YES completion:nil];
    }
    else {
        [self signinAction];
    }
//    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Google Drive" message:@"Comming Soon" preferredStyle:UIAlertControllerStyleAlert];
//    UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
//    [alertController addAction:ok];
//    [self presentViewController:alertController animated:YES completion:nil];
}

- (IBAction)btnFileSharingDropBox:(id)sender{
    ListFilesVC *otherViewCon;
    otherViewCon = [self.storyboard instantiateViewControllerWithIdentifier:@"ListFilesVC"];
    if ([[NSUserDefaults standardUserDefaults] objectForKey:@"dropbox"] == nil || [[[NSUserDefaults standardUserDefaults] objectForKey:@"dropbox"] boolValue] == FALSE) {
        [[DBSession sharedSession] linkFromController:self];
    }
    else if (![[DBSession sharedSession] isLinked]) {
        [[DBSession sharedSession] linkFromController:self];
    }
    else {
        if (!strLoadData) {
            strLoadData = @"";
        }
        [self.navigationController pushViewController:otherViewCon animated:true];
    }
    [self.view removeGestureRecognizer:tap];
    self.fileSharingPopUp.hidden = YES;
    [self.tblViewFileSharing reloadData];
}

-(void)signinAction {
    self.output = [[UITextView alloc] initWithFrame:self.view.bounds];
    self.output.editable = false;
    self.output.contentInset = UIEdgeInsetsMake(20.0, 0.0, 20.0, 0.0);
    self.output.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
    [self.view addSubview:self.output];
    // Initialize the Drive API service & load existing credentials from the keychain if available.
    self.service = [[GTLServiceDrive alloc] init];
    self.service.authorizer =
    [GTMOAuth2ViewControllerTouch authForGoogleFromKeychainForName:kKeychainItemName clientID:kClientID clientSecret:nil];
}

- (GTMOAuth2ViewControllerTouch *)createAuthController {
    GTMOAuth2ViewControllerTouch *authController;
    NSArray *scopes =[NSArray arrayWithObjects:kGTLAuthScopeDriveMetadataReadonly,nil];
    authController = [[GTMOAuth2ViewControllerTouch alloc]
                      initWithScope:[scopes componentsJoinedByString:@" "]
                      clientID:kClientID
                      clientSecret:kClientSecret
                      keychainItemName:kKeychainItemName
                      delegate:self
                      finishedSelector:@selector(viewController:finishedWithAuth:error:)];
    return authController;
}

- (void)viewController:(GTMOAuth2ViewControllerTouch *)viewController
      finishedWithAuth:(GTMOAuth2Authentication *)authResult
                 error:(NSError *)error {
    if (error != nil) {
        [self showAlert:@"Authentication Error" message:error.localizedDescription];
        self.service.authorizer = nil;
        [self dismissViewControllerAnimated:YES completion:nil];
        driveFiles = [[NSMutableArray alloc]init];
        self.service = [[GTLServiceDrive alloc] init];
        self.service.authorizer =
        [GTMOAuth2ViewControllerTouch authForGoogleFromKeychainForName:kKeychainItemName clientID:kClientID clientSecret:kClientSecret];
        if (!self.service.authorizer.canAuthorize) {
            // Not yet authorized, request authorization by pushing the login UI onto the UI stack.
            [self presentViewController:[self createAuthController] animated:YES completion:nil];
        }
        else {
            [self fetchFiles];
        }
//        UIStoryboard *story=[UIStoryboard storyboardWithName:@"Main" bundle:nil];
//        TableVC *objVC = [story instantiateViewControllerWithIdentifier:@"TableVC"];
//        [[self navigationController] pushViewController:objVC animated:YES];
    }
    else {
        self.service.authorizer = authResult;
        [self dismissViewControllerAnimated:YES completion:nil];
    }
}

- (void)fetchFiles {
    GTLQueryDrive *query = [GTLQueryDrive queryForFilesList];
    query.pageSize = 10;
    query.fields = @"files(name)";
    [self.service executeQuery:query delegate:self didFinishSelector:@selector(displayResultWithTicket:finishedWithObject:error:)];
}

- (void)displayResultWithTicket:(GTLServiceTicket *)ticket finishedWithObject:(GTLDriveFileList *)response error:(NSError *)error {
    if (error == nil) {
        NSMutableString *filesString = [[NSMutableString alloc] init];
        if (response.files.count > 0) {
            [filesString appendString:@"Files:\n"];
            for (GTLDriveFile *file in response.files) {
                [filesString appendFormat:@"%@\n", file.name];
                [driveFiles addObject:file.name];
            }
        }
        else {
            [filesString appendString:@"No files found."];
        }
        _tblViewFileSharing.delegate=self;
        _tblViewFileSharing.dataSource=self;
        [_tblViewFileSharing reloadData];
        // self.output.text = filesString;
    }
    else {
        [self showAlert:@"Error" message:error.localizedDescription];
    }
}


- (void)showAlert:(NSString *)title message:(NSString *)message {
    UIAlertController *alert =
    [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *ok =
    [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action) {
         [alert dismissViewControllerAnimated:YES completion:nil];
     }];
    [alert addAction:ok];
    [self presentViewController:alert animated:YES completion:nil];
}

#pragma mark - UITableView Delegate Methods

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if ([[[NSUserDefaults standardUserDefaults] objectForKey:@"dropbox"] boolValue] == YES) {
        UDGetObject(@"dropbox");
        return 1;
    }
    else {
        return [driveFiles count];
    }
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *MyIdentifier = @"cell";
    FileSharingCell *cell =[_tblViewFileSharing dequeueReusableCellWithIdentifier:MyIdentifier];
    if (cell == nil) {
        cell = [[FileSharingCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:MyIdentifier];
    }
    if ([[[NSUserDefaults standardUserDefaults] objectForKey:@"dropbox"] boolValue] == YES) {
        cell.lblNameFileSharing.text = @"Dropbox";
        cell.imgViewFileSharing.image = [UIImage imageNamed:@"dropbox"];
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }
    else {
        cell.lblNameFileSharing.text = [driveFiles objectAtIndex:indexPath.row];
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }
    cell.backgroundColor = [UIColor clearColor];
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if ([[[NSUserDefaults standardUserDefaults] objectForKey:@"dropbox"] boolValue] == YES) {
    NSMutableArray *arrGet = [[NSMutableArray alloc]init];
    NSLog(@"%@",arrGet);
    ListFilesVC *otherViewCon;
    otherViewCon = [self.storyboard instantiateViewControllerWithIdentifier:@"ListFilesVC"];
    [self.navigationController pushViewController:otherViewCon animated:YES];
    }
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath{
    if (editingStyle == UITableViewCellEditingStyleDelete){
        if ([[[NSUserDefaults standardUserDefaults] objectForKey:@"dropbox"] boolValue] == YES) {
        [[DBSession sharedSession] unlinkUserId:objAppShare.strDropBoxUserID];
        objAppShare.strDropBoxUserID = @"";
        UDSetObject(@"", @"dropboxUID");
        [[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"dropbox"];
        [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
        }
    }
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    return YES;
}

-(void)dropboxLoginDone {
    [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"dropbox"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    UDSetObject(objAppShare.strDropBoxUserID, @"dropboxUID");
    ListFilesVC *otherViewCon;
        [self.storyboard instantiateViewControllerWithIdentifier:@"ListFilesVC"];
    [self.navigationController pushViewController:otherViewCon animated:true];
}

@end
