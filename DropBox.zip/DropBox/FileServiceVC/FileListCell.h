//
//  FileListCell.h
//  FileManager
//
//  Created by ami on 11/23/16.
//  Copyright © 2016 com.zaptechsolutions. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FileListCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *lblFileName;
@property (weak, nonatomic) IBOutlet UIImageView *imgViewFile;

@end
