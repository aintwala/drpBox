//
//  InteractionCell.h
//  FileManager
//
//  Created by nilomi on 11/15/16.
//  Copyright © 2016 com.zaptechsolutions. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface InteractionCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIImageView *imgInteractionCell;
@property (weak, nonatomic) IBOutlet UILabel *lblNameInteractionCell;
@property (weak, nonatomic) IBOutlet UILabel *lblSizeInteractionCell;
@property (weak, nonatomic) IBOutlet UILabel *lblDateInteractionCell;

@end
