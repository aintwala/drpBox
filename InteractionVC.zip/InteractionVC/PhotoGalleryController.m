//
//  PhotoGalleryController.m
//  FileManager
//
//  Created by ami on 3/16/17.
//  Copyright © 2017 com.zaptechsolutions. All rights reserved.
//

#import "PhotoGalleryController.h"
#import <Photos/Photos.h>
#import "photoViewCell.h"
#import "PreviewController.h"
#import "appShareManager.h"
@import AVFoundation;
@import AVKit;

@interface PhotoGalleryController () <UICollectionViewDataSource, UICollectionViewDelegate, UIDocumentInteractionControllerDelegate>
{
    appShareManager *objShareManager;
    NSArray *imageArray;
    NSMutableArray *mutableVideoArray;
    NSInteger intIndexpathRow;
    UIVisualEffectView *blurEffectView;
    NSURL *URL;
    AVPlayerViewController *playerViewController;
    AVPlayer * player;
    PHImageManager *manager;
    PHFetchResult *result;
}

@end

@implementation PhotoGalleryController

- (void)viewDidLoad {
    [super viewDidLoad];
    if (_isTrue == true) {
        [self getAllPhotosFromCamera];
    }
    else if (_isTrue == false){
        [self getAllVideosFromCameraRoll];
    }
}

-(void)viewWillDisappear:(BOOL)animated {
    self.navigationItem.title = @"";
}

-(void)getAllVideosFromCameraRoll {
    mutableVideoArray =[[NSMutableArray alloc]init];
    PHVideoRequestOptions *options=[[PHVideoRequestOptions alloc] init];
    options.version = PHVideoRequestOptionsVersionOriginal;
    options.deliveryMode = PHImageRequestOptionsDeliveryModeOpportunistic;
    result = [PHAsset fetchAssetsWithMediaType:PHAssetMediaTypeVideo options:nil];
    NSLog(@"%d", (int)result.count);
    NSMutableArray *arrAsset= [NSMutableArray new];
    [result enumerateObjectsUsingBlock:^(id asset, NSUInteger idx, BOOL *stop) {
        [[PHImageManager defaultManager] requestAVAssetForVideo:asset options:options resultHandler:^(AVAsset *asset, AVAudioMix *audioMix, NSDictionary *info) {
            [arrAsset addObject:asset];
        }];
    }];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 1 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
        for (AVAsset *asset in arrAsset) {
            URL = [(AVURLAsset *)asset URL];
            NSLog(@"%@", URL);
            [mutableVideoArray addObject:@{@"VideoUrl":URL,@"ImageThumbnail":[self imageFromVideoURL]}];
            dispatch_async(dispatch_get_global_queue( DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
                dispatch_async(dispatch_get_main_queue(), ^(void){
                    if (result.count == mutableVideoArray.count) {
                        _collectionView.delegate = self;
                        _collectionView.dataSource = self;
                        [_collectionView reloadData];
                    }
                });
            });
        }
    });
}

- (UIImage *)imageFromVideoURL {
    UIImage *image = nil;
    AVAsset *asset = [[AVURLAsset alloc] initWithURL:URL options:nil];;
    AVAssetImageGenerator *imageGenerator = [[AVAssetImageGenerator alloc] initWithAsset:asset];
    imageGenerator.appliesPreferredTrackTransform = YES;
    Float64 durationSeconds = CMTimeGetSeconds([asset duration]);
    CMTime midpoint = CMTimeMakeWithSeconds(durationSeconds/2.0, 600);
    NSError *error = nil;
    CMTime actualTime;
    CGImageRef halfWayImage = [imageGenerator copyCGImageAtTime:midpoint actualTime:&actualTime error:&error];
    if (halfWayImage != NULL) {
        image = [[UIImage alloc] initWithCGImage:halfWayImage];
    }
    return image;
}

-(void)getAllPhotosFromCamera {
    imageArray=[[NSArray alloc] init];
    _imageManager = [[PHCachingImageManager alloc] init];
    result = [PHAsset fetchAssetsWithMediaType:PHAssetMediaTypeImage options:nil];
    NSLog(@"%d",(int)result.count);
    manager = [PHImageManager defaultManager];
    _collectionView.delegate = self;
    _collectionView.dataSource = self;
    [_collectionView reloadData];
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    if (_isTrue == true) {
        return result.count;
    }
    else {
        return mutableVideoArray.count;
    }
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    photoViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"cell" forIndexPath:indexPath];
    if (_isTrue == true){
        PHImageRequestOptions *requestOptions = [[PHImageRequestOptions alloc] init];
        requestOptions.resizeMode   = PHImageRequestOptionsResizeModeExact;
        requestOptions.deliveryMode = PHImageRequestOptionsDeliveryModeHighQualityFormat;
        requestOptions.synchronous = true;
        [manager requestImageForAsset:result[indexPath.row]
                           targetSize:CGSizeMake(100,100)
                          contentMode:PHImageContentModeDefault
                              options:requestOptions
                        resultHandler:^void(UIImage *image, NSDictionary *info) {
                            cell.imgView.image= image;
                        }];
    }
    else {
        dispatch_async(dispatch_get_global_queue( DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
            dispatch_async(dispatch_get_main_queue(), ^(void){
                cell.imgView.image = [[mutableVideoArray objectAtIndex:indexPath.row] objectForKey:@"ImageThumbnail"];
            });
        });
    }
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    if (_isTrue == true) {
        UIStoryboard* storyboard =[UIStoryboard storyboardWithName:@"Main" bundle:nil];
        PreviewController *preview = [storyboard instantiateViewControllerWithIdentifier:@"PreviewController"];
        PHImageRequestOptions *requestOptions = [[PHImageRequestOptions alloc] init];
        requestOptions.resizeMode   = PHImageRequestOptionsResizeModeExact;
        requestOptions.deliveryMode = PHImageRequestOptionsDeliveryModeHighQualityFormat;
        requestOptions.synchronous = true;
        [manager requestImageForAsset:result[indexPath.row]
                           targetSize:PHImageManagerMaximumSize
                          contentMode:PHImageContentModeDefault
                              options:requestOptions
                        resultHandler:^void(UIImage *image, NSDictionary *info) {
                            [[self navigationController] presentViewController:preview animated:YES completion:nil];
                            preview.imgPreview.image = image;
                        }];
    }
    else {
        playerViewController = [AVPlayerViewController new];
        AVURLAsset *asset = [AVURLAsset assetWithURL: [[mutableVideoArray objectAtIndex:indexPath.row] objectForKey:@"VideoUrl"]];
        AVPlayerItem *item = [AVPlayerItem playerItemWithAsset: asset];
        player = [[AVPlayer alloc] initWithPlayerItem: item];
        [self presentViewController:playerViewController animated:YES completion:nil];
        playerViewController.player = player;
        [playerViewController.view setFrame:CGRectMake(0, 0, self.view.bounds.size.width, self.view.bounds.size.height)];
        playerViewController.showsPlaybackControls = YES;
        playerViewController.view.frame = self.view.frame;
        [playerViewController.player play];
    }
}

#pragma mark collection view cell paddings
- (UIEdgeInsets)collectionView:(UICollectionView*)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section {
    return UIEdgeInsetsMake(0, 0, 0, 0); // top, left, bottom, right
}

- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section {
    return 2.0;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
