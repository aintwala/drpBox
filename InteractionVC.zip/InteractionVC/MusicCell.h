//
//  MusicCell.h
//  FileManager
//
//  Created by ami on 5/31/17.
//  Copyright © 2017 com.zaptechsolutions. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MusicCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIImageView *imgView;
@property (weak, nonatomic) IBOutlet UILabel *lblNameMusic;

@end
