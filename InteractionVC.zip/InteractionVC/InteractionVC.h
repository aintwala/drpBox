//
//  InteractionVC.h
//  FileManager
//
//  Created by nilomi on 11/15/16.
//  Copyright © 2016 com.zaptechsolutions. All rights reserved.
//

#import <UIKit/UIKit.h>
@import GoogleMobileAds;

@interface InteractionVC : UIViewController<UIDocumentInteractionControllerDelegate, UIGestureRecognizerDelegate, UITableViewDelegate, UITableViewDataSource, UISearchBarDelegate>
@property (nonatomic,strong) NSMutableArray *aryInterationData;
@property (weak, nonatomic) IBOutlet UITableView *tblView;
@property (nonatomic, retain) UIDocumentInteractionController *documentInteractionController;
@property BOOL isPressedSearchBtn;
@property (strong, nonatomic) UISearchController *searchController;
@property (strong, nonatomic) IBOutlet UILabel *lblSearchResult;
@property (weak, nonatomic) IBOutlet GADBannerView *bannerView;

@end
