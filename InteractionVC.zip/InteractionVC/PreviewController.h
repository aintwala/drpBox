//
//  PreviewController.h
//  FileManager
//
//  Created by ami on 3/21/17.
//  Copyright © 2017 com.zaptechsolutions. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PreviewController : UIViewController

@property(nonatomic,retain)NSString *receivedImage;
@property (weak, nonatomic) IBOutlet UIImageView *imgPreview;
@property (strong, nonatomic) NSArray *arry;
-(void)doneAction;

@end
