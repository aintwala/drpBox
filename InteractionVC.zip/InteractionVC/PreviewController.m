//
//  PreviewController.m
//  FileManager
//
//  Created by ami on 3/21/17.
//  Copyright © 2017 com.zaptechsolutions. All rights reserved.
//

#import "PreviewController.h"
#import "PhotoGalleryController.h"
#import "photoViewCell.h"

@interface PreviewController ()
{
    UINavigationBar *navBar;
}
@end

@implementation PreviewController

- (void)viewDidLoad {
    [super viewDidLoad];
    navBar = [[UINavigationBar alloc] init];
    UINavigationItem *navItem = [[UINavigationItem alloc] initWithTitle:@""];
    UIBarButtonItem *done = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(doneAction)];
    navItem.leftBarButtonItem = done;
    navBar.items = [NSArray arrayWithObject:navItem];
    navBar.frame = CGRectMake(0, 0, self.view.frame.size.width, 64);
    navBar.backgroundColor = [UIColor clearColor];
    [self.view addSubview:navBar];
}

-(void)doneAction {
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (void)didRotateFromInterfaceOrientation:(UIInterfaceOrientation)fromInterfaceOrientation {
    navBar.frame = CGRectMake(0, 0, self.view.frame.size.width, 64);
}

- (IBAction)shareButtonPressed:(id)sender {
    NSLog(@"shareButton pressed");
    UIImage *img = self.imgPreview.image;
    NSArray *arry = @[img];
    UIActivityViewController *activityVC = [[UIActivityViewController alloc] initWithActivityItems:arry applicationActivities:nil];
    activityVC.excludedActivityTypes = @[UIActivityTypeAssignToContact, UIActivityTypePrint];
    [self presentViewController:activityVC animated:TRUE completion:nil];
}

@end
