//
//  MusicViewController.m
//  FileManager
//
//  Created by ami on 5/31/17.
//  Copyright © 2017 com.zaptechsolutions. All rights reserved.
//

#import "MusicViewController.h"
#import "MusicCell.h"
#import <MediaPlayer/MediaPlayer.h>
#import <AVFoundation/AVFoundation.h>
#import "AppDelegate.h"

@interface MusicViewController () <UITableViewDelegate, UITableViewDataSource>
{
    BOOL isPlaying;
    NSInteger selectedIndex;
    MPMusicPlayerController *controller;
}

@end

@implementation MusicViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    MPMediaQuery *everything = [[MPMediaQuery alloc] init];
    arydirContents = [NSArray new];
     arydirContents = [everything items];
    for (MPMediaItem *song in arydirContents) {
        NSString *songTitle = [song valueForProperty: MPMediaItemPropertyTitle];
        NSLog (@"%@", songTitle);
    }
    self.navigationItem.title = @"Songs";
    isPlaying = false;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return arydirContents.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView
         cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *MyIdentifier = @"cell";
    MusicCell *cell =[_tblView dequeueReusableCellWithIdentifier:MyIdentifier];
    if (cell == nil) {
        cell = [[MusicCell alloc] initWithStyle:UITableViewCellStyleDefault
                                      reuseIdentifier:MyIdentifier];
    }
    cell.lblNameMusic.text = [[arydirContents objectAtIndex:indexPath.row] valueForProperty:MPMediaItemPropertyTitle];
    MPMediaItemArtwork *itemArtwork = [arydirContents[indexPath.row] valueForProperty: MPMediaItemPropertyArtwork];
    if (itemArtwork) {
        cell.imgView.image = [itemArtwork imageWithSize:CGSizeMake(250.0, 250.0)];
    }
    else {
        cell.imgView.image = [UIImage imageNamed:@"song_placeholder"];
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    isPlaying = true;
    selectedIndex = indexPath.row;
    controller = [MPMusicPlayerController applicationMusicPlayer];
    NSMutableArray *SongItem = [[NSMutableArray alloc] init];
    for (MPMediaItem *song in arydirContents) {
        [SongItem addObject:[song valueForProperty: MPMediaItemPropertyPersistentID]];
    }
    NSString *selectedTitle = [SongItem objectAtIndex:selectedIndex];
    MPMediaPropertyPredicate *predicate = [MPMediaPropertyPredicate predicateWithValue:selectedTitle forProperty:MPMediaItemPropertyPersistentID];
    MPMediaQuery *mySongQuery = [[MPMediaQuery alloc] init];
    [mySongQuery addFilterPredicate: predicate];
    [controller setQueueWithQuery:mySongQuery];
    [controller repeatMode];
    [controller play];
    UIImage *buttonImage = [UIImage imageNamed:@"btn_pause"];
    [_btnPlayPause setBackgroundImage:buttonImage forState:UIControlStateNormal];
    [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(updateTime:) userInfo:nil repeats:YES];
}

#pragma mark - Document Directory Delegate

- (UIViewController *)documentInteractionControllerViewControllerForPreview:(UIDocumentInteractionController *)controller
{
    return  self;
}

- (void)documentInteractionController:(UIDocumentInteractionController *)controller willBeginSendingToApplication:(NSString *)application
{
    NSLog(@"Starting to send this puppy to %@", application);
}

- (void)documentInteractionController:(UIDocumentInteractionController *)controller didEndSendingToApplication:(NSString *)application
{
    NSLog(@"We're done sending the document.");
}

- (IBAction)btnPlayPause:(id)sender {
    controller = [MPMusicPlayerController applicationMusicPlayer];
    if (isPlaying == true) {
        UIImage *buttonImage = [UIImage imageNamed:@"btn_play"];
        [_btnPlayPause setBackgroundImage:buttonImage forState:UIControlStateNormal];
        [controller pause];
        isPlaying = false;
    }
    else {
        UIImage *buttonImage = [UIImage imageNamed:@"btn_pause"];
        [_btnPlayPause setBackgroundImage:buttonImage forState:UIControlStateNormal];
        [controller play];
        isPlaying = true;
    }
}

- (IBAction)btnNext:(id)sender {
        selectedIndex = selectedIndex+1;
        NSIndexPath* selectedCellIndexPath= [NSIndexPath indexPathForRow:selectedIndex inSection:0];
        [self tableView:_tblView didSelectRowAtIndexPath:selectedCellIndexPath];
        [_tblView selectRowAtIndexPath:selectedCellIndexPath animated:YES scrollPosition:UITableViewScrollPositionNone];
}

- (void)updateTime:(NSTimer *)timer {
    NSTimeInterval currentTime = controller.currentPlaybackTime;
    NSTimeInterval duration = controller.currentPlaybackRate;
    _musicSlider.maximumValue = duration;
    _musicSlider.value = currentTime;
}

- (IBAction)onSliderMusic:(id)sender
{
    controller.currentPlaybackTime = _musicSlider.value;
}

- (IBAction)btnPrevious:(id)sender {
    if(selectedIndex>0) {
        selectedIndex = selectedIndex-1;
        NSIndexPath* selectedCellIndexPath= [NSIndexPath indexPathForRow:selectedIndex inSection:0];
        [self tableView:_tblView didSelectRowAtIndexPath:selectedCellIndexPath];
        [_tblView selectRowAtIndexPath:selectedCellIndexPath animated:YES scrollPosition:UITableViewScrollPositionNone];
    }
}

- (IBAction)btnMuteUnmute:(id)sender {
}

- (IBAction)onVolume:(id)sender {
}

@end
