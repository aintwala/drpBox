//
//  InteractionCell.m
//  FileManager
//
//  Created by nilomi on 11/15/16.
//  Copyright © 2016 com.zaptechsolutions. All rights reserved.
//

#import "InteractionCell.h"

@implementation InteractionCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
