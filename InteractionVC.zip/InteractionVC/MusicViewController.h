//
//  MusicViewController.h
//  FileManager
//
//  Created by ami on 5/31/17.
//  Copyright © 2017 com.zaptechsolutions. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MediaPlayer/MediaPlayer.h>

@interface MusicViewController : UIViewController {
    NSArray * arydirContents;
    //MPMusicPlayerController *player;
    
}
@property (weak, nonatomic) IBOutlet UISlider *musicSlider;
@property (weak, nonatomic) IBOutlet UIButton *btnPlayPause;

@property (weak, nonatomic) IBOutlet UITableView *tblView;
@property (nonatomic, retain) UIDocumentInteractionController *documentInteractionController;
- (IBAction)btnNext:(id)sender;

@end
