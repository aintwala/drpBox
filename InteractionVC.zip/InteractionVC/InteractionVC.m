//
//  InteractionVC.m
//  FileManager
//
//  Created by nilomi on 11/15/16.
//  Copyright © 2016 com.zaptechsolutions. All rights reserved.
//

#import "InteractionVC.h"
#import "InteractionCell.h"
#import "appShareManager.h"
#import "HomeVC.h"
#import "DownloadVC.h"
#import <Photos/Photos.h>
#import "PhotoGalleryController.h"
#import <MediaPlayer/MediaPlayer.h>
#import "MusicViewController.h"

@interface InteractionVC ()<UISearchResultsUpdating ,UISearchControllerDelegate>
{
    NSArray * arydirContents;
    NSMutableArray *filteredContentList;
    appShareManager *objShareManager;
    BOOL IsSearching;
    NSMutableArray *mutableArray;
    MPMediaQuery *everything;
    NSString *fileName;
}
@end

@implementation InteractionVC

- (void)viewDidLoad {
    [super viewDidLoad];
    IsSearching = false;
    self.navigationController.navigationBar.translucent = NO;
    objShareManager = [appShareManager sharedManager];
    filteredContentList = [[NSMutableArray alloc] init];
    _tblView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    _tblView.backgroundColor = [UIColor colorWithRed:65.0f/255.0f green:101.0f/255.0f blue:181.0f/255.0f alpha:40.0f/255.0f];
    UILongPressGestureRecognizer *lpgr = [[UILongPressGestureRecognizer alloc]
                                          initWithTarget:self action:@selector(handleLongPress:)];
    lpgr.minimumPressDuration = 2.0;
    lpgr.delegate = self;
    _tblView.allowsMultipleSelectionDuringEditing = NO;
    [self.searchController.searchBar setTintColor:[UIColor whiteColor]];
    [[UITextField appearanceWhenContainedIn:[UISearchBar class], nil] setTintColor:[UIColor darkGrayColor]];
    self.searchController = [[UISearchController alloc] initWithSearchResultsController:nil];
    self.searchController.searchBar.tintColor = [UIColor whiteColor];
    self.searchController.searchResultsUpdater = self;
    self.searchController.delegate = self;
    self.searchController.dimsBackgroundDuringPresentation = NO;
    self.searchController.searchBar.delegate = self;
    self.tblView.tableHeaderView = self.searchController.searchBar;
    self.definesPresentationContext = YES;
    filteredContentList = [[NSMutableArray arrayWithArray:_aryInterationData]mutableCopy];
    [self.tblView addGestureRecognizer:lpgr];
    if (_aryInterationData.count == 0 && ([objShareManager.strTitle isEqualToString:@"Documents"] || [objShareManager.strTitle isEqualToString:@"Others"])) {
        _lblSearchResult.text = @"No Data Available";
        _lblSearchResult.hidden = NO;
    }
    else if ([objShareManager.strTitle isEqualToString:@"All"] || [objShareManager.strTitle isEqualToString:@"Photos"] || [objShareManager.strTitle isEqualToString:@"Videos"] || [objShareManager.strTitle isEqualToString:@"Musics"])
    {
        _lblSearchResult.text = @"No Records Found";
        _lblSearchResult.hidden = YES;
    }
    [_tblView reloadData];
}

- (void)viewWillAppear:(BOOL)animated {
    self.bannerView.adUnitID = @"ca-app-pub-4018971263267828/6787743794";
    self.bannerView.rootViewController = self;
    [self.bannerView loadRequest:[GADRequest request]];
    [self.navigationController setToolbarHidden:YES animated:animated];
    [self.navigationController.navigationBar setTintColor:[UIColor whiteColor]];
    self.navigationItem.title = objShareManager.strTitle;
    self.navigationController.navigationBar.backgroundColor  = [UIColor clearColor];
    self.searchController.searchBar.barTintColor = [UIColor colorWithRed:65.0f/255.0f green:101.0f/255.0f blue:181.0f/255.0f alpha:0.0/255.0f];
    [self.searchController.searchBar setTintColor:[UIColor whiteColor]];
    if (_isPressedSearchBtn==YES) {
        [self.tblView setContentOffset:CGPointMake(0, 0)];
        self.searchController.active = TRUE;
        [self.searchController becomeFirstResponder];
    }
    else {
        [self.tblView setContentOffset:CGPointMake(0, 44)];
    }
}

-(void)viewWillDisappear:(BOOL)animated {
    self.navigationItem.title = @"";
}

-(void)viewDidDisappear:(BOOL)animated {
    _isPressedSearchBtn = false;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

#pragma mark - TableView Delegate Methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (IsSearching)
    {
        return [filteredContentList count];
    }
    else {
        if ([objShareManager.strTitle isEqualToString:@"Photos"] || [objShareManager.strTitle isEqualToString:@"Videos"] ||  [objShareManager.strTitle isEqualToString:@"Musics"])
        {
        return [_aryInterationData count] + 1;
        }
        else if ([objShareManager.strTitle isEqualToString:@"All"])
        {
          return [_aryInterationData count] + 3;
        }
        else {
            return [_aryInterationData count];
        }
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView
         cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *MyIdentifier = @"cell";
    InteractionCell *cell =[_tblView dequeueReusableCellWithIdentifier:MyIdentifier forIndexPath:indexPath];
    if (cell == nil) {
        cell = [[InteractionCell alloc] initWithStyle:UITableViewCellStyleDefault
                                      reuseIdentifier:MyIdentifier];
    }
    if (IsSearching){
        _lblSearchResult.hidden = YES;
        cell.lblDateInteractionCell.hidden = NO;
        cell.lblSizeInteractionCell.hidden = NO;
        cell.backgroundColor = [UIColor clearColor];
        cell.lblNameInteractionCell.text = [filteredContentList objectAtIndex:indexPath.row];
        UIDocumentInteractionController *documentInteractionController = [UIDocumentInteractionController interactionControllerWithURL:[NSURL fileURLWithPath:[filteredContentList objectAtIndex:indexPath.row]]];
        NSArray *aryIcons = documentInteractionController.icons;
        cell.imgInteractionCell.image = [aryIcons objectAtIndex:0];
        cell.lblNameInteractionCell.text=documentInteractionController.name;
        NSError *error = nil;
        NSDictionary *attribs = [[NSFileManager defaultManager] attributesOfItemAtPath:[filteredContentList objectAtIndex:indexPath.row] error:&error];
        if (attribs) {
            NSString *string = [NSByteCountFormatter stringFromByteCount:[attribs fileSize] countStyle:NSByteCountFormatterCountStyleFile];
            cell.lblSizeInteractionCell.text = string;
            NSLog(@"%@", string);
        }
        NSDateFormatter *df = [[NSDateFormatter alloc] init];
        [df setDateFormat:@"dd-MM-yyyy"];
        NSDate *result = [attribs valueForKey:NSFileCreationDate];
        NSString *dateString = [df stringFromDate:result];
        cell.lblDateInteractionCell.text = dateString;
    }
    else {
        int index = (int)indexPath.row;
        if ([objShareManager.strTitle isEqualToString:@"Videos"] || [objShareManager.strTitle isEqualToString:@"Photos"] || [objShareManager.strTitle isEqualToString:@"Musics"])
        {
            index --;
        } else if ([objShareManager.strTitle isEqualToString:@"All"]) {
            index --;
            index --;
            index --;
        }
        if (indexPath.row == 0 && ([objShareManager.strTitle isEqualToString:@"Photos"])) {
            cell.lblNameInteractionCell.text = @"Photo Librery";
            cell.imgInteractionCell.image = [UIImage imageNamed:@"gallery"];
            cell.lblDateInteractionCell.hidden = YES;
            cell.lblSizeInteractionCell.hidden = YES;
            cell.backgroundColor = [UIColor clearColor];
        }
        else if (indexPath.row == 0 && ([objShareManager.strTitle isEqualToString:@"Videos"])) {
            cell.lblNameInteractionCell.text = @"Video Librery";
            cell.imgInteractionCell.image = [UIImage imageNamed:@"gallery"];
            cell.lblDateInteractionCell.hidden = YES;
            cell.lblSizeInteractionCell.hidden = YES;
            cell.backgroundColor = [UIColor clearColor];
        }
       else if (indexPath.row == 0 && ([objShareManager.strTitle isEqualToString:@"Musics"])) {
        cell.lblNameInteractionCell.text = @"Music Librery";
        cell.imgInteractionCell.image = [UIImage imageNamed:@"Music"];
        cell.lblDateInteractionCell.hidden = YES;
        cell.lblSizeInteractionCell.hidden = YES;
        cell.backgroundColor = [UIColor clearColor];
    }
        else if ((indexPath.row == 0 || indexPath.row == 1 || indexPath.row == 2)  && ([objShareManager.strTitle isEqualToString:@"All"])) {
            if (indexPath.row == 0) {
                cell.lblNameInteractionCell.text = @"Photo Librery";
                cell.imgInteractionCell.image = [UIImage imageNamed:@"gallery"];
            } else if (indexPath.row == 1){
            cell.lblNameInteractionCell.text = @"Video Librery";
                cell.imgInteractionCell.image = [UIImage imageNamed:@"gallery"];
            }
            else if (indexPath.row == 2){
            cell.lblNameInteractionCell.text = @"Music Librery";
                cell.imgInteractionCell.image = [UIImage imageNamed:@"Music"];
            }
            cell.lblDateInteractionCell.hidden = YES;
            cell.lblSizeInteractionCell.hidden = YES;
            cell.backgroundColor = [UIColor clearColor];
        }
        else {
            cell.lblDateInteractionCell.hidden = NO;
            cell.lblSizeInteractionCell.hidden = NO;
            if (_aryInterationData != nil) {
            _lblSearchResult.hidden = YES;
            cell.backgroundColor = [UIColor clearColor];
            cell.lblNameInteractionCell.text =[_aryInterationData objectAtIndex:index];
            UIDocumentInteractionController *documentInteractionController = [UIDocumentInteractionController interactionControllerWithURL:[NSURL fileURLWithPath:[_aryInterationData objectAtIndex:index]]];
            NSArray *aryIcons = documentInteractionController.icons;
            cell.imgInteractionCell.image = [aryIcons objectAtIndex:0];
            cell.lblNameInteractionCell.text=documentInteractionController.name;
            NSError *error = nil;
            NSDictionary *attribs = [[NSFileManager defaultManager] attributesOfItemAtPath:[_aryInterationData objectAtIndex:index] error:&error];
            if (attribs) {
                NSString *string = [NSByteCountFormatter stringFromByteCount:[attribs fileSize] countStyle:NSByteCountFormatterCountStyleFile];
                cell.lblSizeInteractionCell.text = string;
                NSLog(@"%@", string);
            }
            NSDateFormatter *df = [[NSDateFormatter alloc] init];
            [df setDateFormat:@"dd-MM-yyyy"];
            NSDate *result = [attribs valueForKey:NSFileCreationDate];
            NSString *dateString = [df stringFromDate:result];
            cell.lblDateInteractionCell.text = dateString;
            }
        }
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (IsSearching) {
        self.documentInteractionController = [UIDocumentInteractionController interactionControllerWithURL: [NSURL fileURLWithPath:[filteredContentList  objectAtIndex:indexPath.row]]];
        self.documentInteractionController.delegate = self;
        [self.documentInteractionController presentPreviewAnimated:YES];
    }
    else {
            int index = (int)indexPath.row;
            if ([objShareManager.strTitle isEqualToString:@"Videos"] || [objShareManager.strTitle isEqualToString:@"Photos"] || [objShareManager.strTitle isEqualToString:@"Musics"])
            {
                index --;
            }
            else if ([objShareManager.strTitle isEqualToString:@"All"]){
                index --;
                index --;
                index --;
            }
            if ((indexPath.row == 0 || indexPath.row == 1 || indexPath.row == 2) && ([objShareManager.strTitle isEqualToString:@"All"] || [objShareManager.strTitle isEqualToString:@"Photos"] || [objShareManager.strTitle isEqualToString:@"Videos"] || [objShareManager.strTitle isEqualToString:@"Musics"])) {
                if (indexPath.row == 0 && ([objShareManager.strTitle isEqualToString:@"All"] || [objShareManager.strTitle isEqualToString:@"Photos"])) {
                    UIStoryboard* storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
                    PhotoGalleryController* objphotoVC = [storyboard instantiateViewControllerWithIdentifier:@"PhotoGalleryController"];
                    objphotoVC.isTrue = true;
                    [[self navigationController] pushViewController:objphotoVC animated:YES];
                }
                else if ((indexPath.row == 0 && ([objShareManager.strTitle isEqualToString:@"Videos"])) || (indexPath.row == 1 && ([objShareManager.strTitle isEqualToString:@"All"]))){
                    UIStoryboard* storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
                    PhotoGalleryController* objphotoVC = [storyboard instantiateViewControllerWithIdentifier:@"PhotoGalleryController"];
                    objphotoVC.isTrue = false;
                    [[self navigationController] pushViewController:objphotoVC animated:YES];
                }
                else if ((indexPath.row == 0 && ([objShareManager.strTitle isEqualToString:@"Musics"])) || (indexPath.row == 2 && ([objShareManager.strTitle isEqualToString:@"All"]))){
                    UIStoryboard* storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
                    MusicViewController* objphotoVC = [storyboard instantiateViewControllerWithIdentifier:@"MusicViewController"];
                    [[self navigationController] pushViewController:objphotoVC animated:YES];
                }
            else {
                self.documentInteractionController = [UIDocumentInteractionController interactionControllerWithURL: [NSURL fileURLWithPath:[_aryInterationData  objectAtIndex:index]]];
                self.documentInteractionController.delegate = self;
                [self.documentInteractionController presentPreviewAnimated:YES];
               }
            }
            else {
            self.documentInteractionController = [UIDocumentInteractionController interactionControllerWithURL: [NSURL fileURLWithPath:[_aryInterationData  objectAtIndex:index]]];
                self.documentInteractionController.delegate = self;
                [self.documentInteractionController presentPreviewAnimated:YES];
            }
        }
        [self.tblView reloadData];
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath{
    if (editingStyle == UITableViewCellEditingStyleDelete){
        if ([objShareManager.strTitle isEqualToString:@"All"]) {
            fileName = [filteredContentList objectAtIndex:indexPath.row - 3];
        }
        else {
            fileName = [filteredContentList objectAtIndex:indexPath.row - 1];
        }
        NSArray *parts = [fileName componentsSeparatedByString:@"/"];
        NSString *name = [parts lastObject];
        NSFileManager *fileManager = [NSFileManager defaultManager];
        NSString *documentsPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
        NSString *filePath = [documentsPath stringByAppendingPathComponent:name];
        NSError *error;
        BOOL success = [fileManager removeItemAtPath:filePath error:&error];
        if (success) {
            [objShareManager.aryAllDocDireFiles removeObject:fileName];
            if ([objShareManager.strTitle isEqualToString:@"All"]) {
            [_aryInterationData removeObjectAtIndex:indexPath.row - 3];
            [filteredContentList removeObjectAtIndex:indexPath.row - 3];
            }
            else {
                [_aryInterationData removeObjectAtIndex:indexPath.row - 1];
                [filteredContentList removeObjectAtIndex:indexPath.row - 1];
            }
            NSMutableArray *arrGet=[[NSMutableArray alloc]initWithArray:UDGetObject(@"Download")];
            if ([[arrGet valueForKey:@"name"] containsObject:name]) {
                for (int i=0; i<arrGet.count; i++) {
                    if ([name isEqualToString:[[arrGet objectAtIndex:i]valueForKey:@"name"]]) {
                        [arrGet removeObjectAtIndex:i];
                        UDRemoveObject(@"Download");
                        UDSetObject(arrGet, @"Download");
                        break;
                    }
                }
            }
            [_tblView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
        }
        else {
            NSLog(@"Could not delete file -:%@ ",[error localizedDescription]);
        }
    }
    if ([objShareManager.strTitle isEqualToString:@"Documents"] || [objShareManager.strTitle isEqualToString:@"Others"]) {
    _lblSearchResult.hidden = NO;
    }
    [self.tblView reloadData];
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}

- (BOOL)gestureRecognizer:(UIPanGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UISwipeGestureRecognizer *)otherGestureRecognizer
{
    return YES;
}

#pragma mark - Long Press Gesture

-(void)handleLongPress:(UILongPressGestureRecognizer *)gestureRecognizer {
    CGPoint p = [gestureRecognizer locationInView:self.tblView];
    NSIndexPath *indexPath = [self.tblView indexPathForRowAtPoint:p];
    if (indexPath == nil) {
        NSLog(@"long press on table view but not on a row");
    }
    else if (gestureRecognizer.state == UIGestureRecognizerStateBegan) {
        self.documentInteractionController = [UIDocumentInteractionController interactionControllerWithURL: [filteredContentList objectAtIndex:indexPath.row]];
        self.documentInteractionController.delegate = self;
        [self.documentInteractionController presentOptionsMenuFromRect:CGRectZero inView:self.view animated:YES];
        NSLog(@"long press on table view at row %ld", indexPath.row);
    }
    else {
        NSLog(@"gestureRecognizer.state = %ld", gestureRecognizer.state);
    }
}

#pragma mark - Document Directory Delegate

- (UIViewController *)documentInteractionControllerViewControllerForPreview:(UIDocumentInteractionController *)controller
{
    return  self;
}

- (void)documentInteractionController:(UIDocumentInteractionController *)controller willBeginSendingToApplication:(NSString *)application
{
    NSLog(@"Starting to send this puppy to %@", application);
}

- (void)documentInteractionController:(UIDocumentInteractionController *)controller didEndSendingToApplication:(NSString *)application
{
    NSLog(@"We're done sending the document.");
}

#pragma mark - Update Search Result

- (void)updateSearchResultsForSearchController:(UISearchController *)searchController {
    if (!searchController.active) {
        [filteredContentList removeAllObjects];
        filteredContentList = [[NSMutableArray arrayWithArray:_aryInterationData] mutableCopy];
        dispatch_async(dispatch_get_main_queue(), ^{
            [self.tblView reloadData];
        });
    }
    else {
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF contains [c] %@", self.searchController.searchBar.text];
        NSArray *aryData = [_aryInterationData filteredArrayUsingPredicate:predicate];
        filteredContentList = [aryData mutableCopy];
        if(filteredContentList.count == 0) {
            _lblSearchResult.hidden = NO;
        }
        else {
            _lblSearchResult.hidden = YES;
        }
    }
    [self.tblView reloadData];
}

- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar {
    NSLog(@"Cancel clicked");
    _lblSearchResult.hidden = YES;
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText {
    [filteredContentList removeAllObjects];
    if (searchText.length != 0) {
        IsSearching = true;
    }
    else {
        IsSearching = false;
    }
    if([self.searchController.searchBar.text length] != 0) {
        _searchController.active = YES;
        [self updateSearchResultsForSearchController:_searchController];
    }
    else {
        _searchController.active = NO;
        if(_aryInterationData.count != 0) {
            _lblSearchResult.hidden = YES;
        }
    }
    [_tblView reloadData];
}

@end
