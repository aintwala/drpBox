//
//  PhotoGalleryController.h
//  FileManager
//
//  Created by ami on 3/16/17.
//  Copyright © 2017 com.zaptechsolutions. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Photos/Photos.h>

@interface PhotoGalleryController : UIViewController

@property (nonatomic)  BOOL isTrue;
@property (nonatomic, retain) UIDocumentInteractionController *documentInteractionController;
@property(nonatomic , strong) PHCachingImageManager *imageManager;
@property(nonatomic , strong) UIImageView *imgView;
@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;
@property (weak, nonatomic) IBOutlet UILabel *lblEmpty;

@end
