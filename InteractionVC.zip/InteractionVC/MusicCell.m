//
//  MusicCell.m
//  FileManager
//
//  Created by ami on 5/31/17.
//  Copyright © 2017 com.zaptechsolutions. All rights reserved.
//

#import "MusicCell.h"

@implementation MusicCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
