//
//  photoViewCell.m
//  FileManager
//
//  Created by ami on 3/16/17.
//  Copyright © 2017 com.zaptechsolutions. All rights reserved.
//

#import "photoViewCell.h"

@implementation photoViewCell

@end
